# Healthcare Appointment Reminder System - Quick Start Guide

## 🚀 Getting Started in 10 Minutes

### Prerequisites
- Node.js 18+ (or Python 3.9+)
- Docker & Docker Compose
- PostgreSQL (or use Docker)
- Git
- Text editor (VS Code recommended)

---

## Option A: Quick Start with Docker (Recommended)

### Step 1: Clone Repository & Setup
```bash
git clone https://github.com/your-org/healthcare-app.git
cd healthcare-app
cp .env.example .env
```

### Step 2: Edit .env File
```bash
# Set your SMS provider credentials
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# Create a strong JWT secret
JWT_SECRET=your_super_secret_key_minimum_32_characters_long
```

### Step 3: Start Everything
```bash
docker-compose up -d
```

### Step 4: Initialize Database
```bash
docker exec healthcare_db psql -U healthcare_admin -d healthcare_db -f /docker-entrypoint-initdb.d/init.sql
```

### Step 5: Access the System
- **Web Dashboard**: http://localhost:3001
- **API**: http://localhost:3000
- **Admin Login**: admin@clinic.cm / admin123

Done! System is running ✅

---

## Option B: Manual Setup (Development)

### Step 1: Backend Setup
```bash
cd backend
npm install

# Create .env file
cp .env.example .env

# Create database
createdb healthcare_db

# Run migrations
npm run migrate

# Start backend
npm run dev
```

### Step 2: Frontend Setup
```bash
cd ../frontend
npm install

# Start frontend
npm start
```

Access at http://localhost:3000

---

## 📚 Quick Reference

### Create Your First Patient (Using API)

```bash
# 1. Get JWT token (for testing)
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@clinic.cm","password":"admin123"}'

# Response: {"token":"eyJhbGciOiJIUzI1NiI..."}

# 2. Create patient
curl -X POST http://localhost:3000/api/patients \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "patient_code":"PAT-2024-0001",
    "first_name":"Jean",
    "last_name":"Nkosi",
    "phone_number":"+237677123456",
    "gender":"M",
    "conditions":{"hiv":true,"tb":false}
  }'

# Response: 
{
  "id":"uuid-here",
  "patient_code":"PAT-2024-0001",
  "first_name":"Jean",
  "created_at":"2024-03-31T10:30:00Z"
}
```

### Schedule Appointment

```bash
curl -X POST http://localhost:3000/api/appointments \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "patient_id":"uuid-from-above",
    "appointment_type":"hiv_trimester",
    "scheduled_date":"2024-06-15T09:00:00Z",
    "location":"Clinic A, Room 5"
  }'
```

### Record Health Metric

```bash
curl -X POST http://localhost:3000/api/metrics/patient-uuid \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "metric_type":"hiv_viral_load",
    "metric_value":"45",
    "unit":"copies/mL",
    "measurement_date":"2024-03-31",
    "status":"normal"
  }'
```

---

## 🧪 Testing

### Test SMS Integration
1. Go to SMS Settings in dashboard
2. Enter Twilio credentials
3. Click "Send Test SMS"
4. Check your phone for test message

### Test Appointment Reminders
```bash
# Manually trigger reminder scheduler
curl -X POST http://localhost:3000/api/admin/trigger-reminders \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## 🔧 Troubleshooting

### Database Connection Error
```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check logs
docker logs healthcare_db

# Reconnect
docker restart healthcare_db
```

### SMS Not Sending
1. Verify Twilio credentials in .env
2. Check SMS logs: `SELECT * FROM sms_notifications;`
3. Check API logs: `docker logs healthcare_api`

### Frontend Not Loading
```bash
# Clear cache and rebuild
cd frontend
rm -rf node_modules package-lock.json
npm install
npm start
```

---

## 📖 Next Steps

1. **Configure SMS Provider**
   - Go to Settings tab
   - Enter Twilio API credentials
   - Test SMS delivery

2. **Create SMS Templates**
   - Go to SMS Templates tab
   - Customize reminder messages
   - Save templates

3. **Add Staff Users**
   - Go to Admin > Users
   - Create staff accounts
   - Assign roles (staff, nurse, doctor, admin)

4. **Import Patient Data**
   - Use "Import from CSV" feature
   - Map hospital patient codes
   - Bulk create patients

5. **Schedule First Appointments**
   - Select patient
   - Click "New Appointment"
   - Choose appointment type
   - Set date and time
   - Save

6. **Test Reminders**
   - Create appointment 2 days from now
   - System automatically sends SMS
   - Verify patient receives message

---

## 📊 Common Tasks

### View Upcoming Appointments
```
Dashboard → Upcoming Appointments
```

### Find Overdue Patients
```
Dashboard → Alerts section shows overdue patients
```

### Check SMS Delivery Status
```
Dashboard → SMS Notifications → View delivery logs
```

### Generate Report
```
Reports → Select date range → Download CSV/PDF
```

### Backup Database
```bash
docker exec healthcare_db pg_dump -U healthcare_admin healthcare_db > backup.sql
```

### Restore Database
```bash
docker exec -i healthcare_db psql -U healthcare_admin healthcare_db < backup.sql
```

---

## 🔐 Security Notes

1. **Change Default Password** immediately
   - Click Admin > Users
   - Edit admin user
   - Set new password

2. **Create HTTPS Certificate** for production
   ```bash
   # Using Let's Encrypt (free)
   certbot certonly --standalone -d yourdomain.com
   ```

3. **Configure Firewall**
   - Only allow HTTPS (443)
   - Restrict API access by IP
   - Enable DDoS protection

4. **Enable Backups**
   ```bash
   # Automatic daily backups
   0 2 * * * pg_dump healthcare_db | gzip > /backups/$(date +%Y%m%d).sql.gz
   ```

---

## 📞 Support

**Documentation**: https://docs.yourdomain.com
**API Docs**: http://localhost:3000/api/docs
**Issue Tracker**: https://github.com/your-org/healthcare-app/issues

---

## 🎓 Learning Path

**Day 1**: Deploy system & add test patients
**Day 2**: Configure SMS provider & test messages
**Day 3**: Create appointment templates
**Day 4**: Import real patient data
**Day 5**: Train staff on system
**Week 2**: Go live with first cohort
**Week 3-4**: Monitor & optimize

---

## 💡 Pro Tips

1. **Test on staging first** before any changes to production
2. **Keep SMS provider credentials secure** - never commit to git
3. **Monitor SMS costs** - set monthly budget alerts in Twilio dashboard
4. **Schedule reminders during business hours** for better response rates
5. **Enable SMS response handling** to let patients confirm via SMS
6. **Keep backup power** for continuous SMS delivery during outages
7. **Train staff extensively** on system usage and troubleshooting

---

## 📝 System Architecture

```
┌─────────────────────────────────────────────┐
│         React Web Dashboard                 │
│    (Appointments, Patients, Metrics)        │
└──────────────┬──────────────────────────────┘
               │ HTTPS
┌──────────────▼──────────────────────────────┐
│       Express API Server (Node.js)          │
│  (Patient CRUD, Appointments, Metrics)      │
└──────────────┬──────────────────────────────┘
               │
    ┌──────────┼──────────┐
    │          │          │
┌───▼────┐ ┌──▼──────┐ ┌─▼──────────┐
│PostgreS│ │  Redis  │ │ Bull Queue │
│   QL   │ │ (Cache) │ │(Reminders) │
└────────┘ └─────────┘ └──────┬─────┘
                               │
                        ┌──────▼──────┐
                        │  Twilio SMS │
                        │   Gateway   │
                        └─────────────┘
```

---

## ✅ Verification Checklist

- [ ] Database connected (check with `npm run db:test`)
- [ ] API running on port 3000 (curl http://localhost:3000/api/health)
- [ ] Frontend running on port 3001 (open http://localhost:3001)
- [ ] Can login with admin@clinic.cm / admin123
- [ ] Can create new patient
- [ ] Can schedule appointment
- [ ] Can see dashboard with sample data
- [ ] SMS provider configured
- [ ] Test SMS sending works
- [ ] System ready for training

---

## 🚨 Emergency Contacts

**System Down?**
- Restart services: `docker-compose restart`
- Check logs: `docker logs healthcare_api`
- Database issue: `docker logs healthcare_db`
- Network issue: `docker network ls`

**Data Recovery?**
- Restore from backup: `./scripts/restore-backup.sh backup.sql`
- Check audit logs: `SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100;`

---

**Start developing!** 🎉

For detailed documentation, see:
- Architecture: `healthcare-app-architecture.md`
- Deployment: `deployment-guide.md`
- API Docs: Backend code comments
- Frontend: Component documentation

Good luck! 🚀
