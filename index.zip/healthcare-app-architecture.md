# Healthcare Appointment Reminder System - Complete Architecture

## System Overview
A comprehensive patient management system for hospital appointment reminders with SMS alerts, condition tracking (HIV, TB), and automated reminders for trimester and monthly checkups.

---

## 1. FRONTEND ARCHITECTURE

### Frontend Stack
- **Framework**: React 18+ (Web Dashboard)
- **Mobile**: React Native / Flutter (for SMS-native mobile app)
- **UI Library**: Tailwind CSS + Custom Components
- **State Management**: Redux or Zustand
- **Real-time**: WebSocket for live updates

### Key Pages/Modules
1. **Patient Dashboard** - Overview of appointments, health metrics
2. **Appointment Manager** - Create, reschedule, cancel appointments
3. **Health Metrics Display** - Viral load, TB control status, etc.
4. **SMS Management** - Configure and send reminder templates
5. **Admin Panel** - Manage patients, appointments, and alert settings
6. **Reports** - Appointment compliance, missed appointments, metrics trends

---

## 2. BACKEND ARCHITECTURE

### Backend Stack
- **Runtime**: Node.js (Express.js) or Python (Django/FastAPI)
- **Database**: PostgreSQL (primary) + Redis (caching)
- **SMS Provider**: Twilio, AWS SNS, or local SMS gateway (e.g., Gammu)
- **Scheduler**: Bull Queue or APScheduler (for reminder jobs)
- **Authentication**: JWT tokens + role-based access control (RBAC)

### Core Microservices/Modules

#### A. Patient Service
```
POST   /api/patients                 - Create patient
GET    /api/patients/:id             - Get patient details
PUT    /api/patients/:id             - Update patient info
GET    /api/patients/:id/timeline    - Get patient appointment history
```

#### B. Appointment Service
```
POST   /api/appointments             - Schedule appointment
GET    /api/appointments/:id         - Get appointment details
PUT    /api/appointments/:id         - Reschedule/update appointment
DELETE /api/appointments/:id         - Cancel appointment
GET    /api/appointments/patient/:patientId - List patient appointments
GET    /api/appointments/upcoming    - List upcoming appointments (for reminders)
```

#### C. Health Metrics Service
```
POST   /api/metrics/:patientId       - Record health metric (viral load, TB status)
GET    /api/metrics/:patientId       - Get patient metrics
GET    /api/metrics/:patientId/:type - Get specific metric history
```

#### D. SMS/Notification Service
```
POST   /api/notifications/send       - Send SMS reminder
POST   /api/notifications/schedule   - Schedule SMS for future date
GET    /api/notifications/templates  - List SMS templates
POST   /api/notifications/templates  - Create custom SMS template
```

#### E. Scheduling Service (Background Worker)
- **Job**: Daily check for upcoming appointments (7 days, 2 days, 1 day before)
- **Action**: Trigger SMS notifications based on template
- **Retry Logic**: If SMS fails, retry up to 3 times with exponential backoff
- **Logging**: All SMS delivery attempts logged for compliance

---

## 3. DATABASE SCHEMA

### Patients Table
```sql
CREATE TABLE patients (
  id UUID PRIMARY KEY,
  patient_code VARCHAR(50) UNIQUE NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  phone_number VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(100),
  date_of_birth DATE,
  gender ENUM('M', 'F', 'Other'),
  conditions JSON, -- {hiv: bool, tb: bool, other: []}
  enrollment_date TIMESTAMP,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Appointments Table
```sql
CREATE TABLE appointments (
  id UUID PRIMARY KEY,
  patient_id UUID REFERENCES patients(id),
  appointment_type ENUM('hiv_trimester', 'tb_6month', 'monthly_pickup'),
  scheduled_date DATETIME NOT NULL,
  last_appointment_date DATETIME,
  location VARCHAR(255),
  notes TEXT,
  status ENUM('scheduled', 'completed', 'missed', 'rescheduled', 'cancelled'),
  reminder_sent BOOLEAN DEFAULT false,
  reminder_sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  INDEX idx_patient_date (patient_id, scheduled_date),
  INDEX idx_status (status)
);
```

### Health Metrics Table
```sql
CREATE TABLE health_metrics (
  id UUID PRIMARY KEY,
  patient_id UUID REFERENCES patients(id),
  metric_type ENUM('hiv_viral_load', 'tb_status', 'cd4_count', 'other'),
  metric_value VARCHAR(255),
  unit VARCHAR(50),
  measurement_date DATE,
  normal_range VARCHAR(100),
  status ENUM('normal', 'abnormal', 'critical'),
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  INDEX idx_patient_metric (patient_id, metric_type, measurement_date DESC)
);
```

### SMS Notifications Table
```sql
CREATE TABLE sms_notifications (
  id UUID PRIMARY KEY,
  patient_id UUID REFERENCES patients(id),
  appointment_id UUID REFERENCES appointments(id),
  message TEXT NOT NULL,
  phone_number VARCHAR(20),
  status ENUM('pending', 'sent', 'failed', 'bounced'),
  scheduled_for DATETIME,
  sent_at TIMESTAMP,
  delivery_status VARCHAR(255),
  attempt_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  INDEX idx_patient_status (patient_id, status),
  INDEX idx_scheduled (scheduled_for)
);
```

### SMS Templates Table
```sql
CREATE TABLE sms_templates (
  id UUID PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  appointment_type VARCHAR(50),
  message TEXT NOT NULL,
  variables JSON, -- {patient_name, appointment_date, location}
  days_before INT, -- Send 7, 2, 1 days before
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 4. SMS REMINDER WORKFLOW

### Trigger Points
1. **T-7 Days**: Initial reminder - "Your appointment is in one week"
2. **T-2 Days**: Second reminder - "Appointment in 2 days, please confirm"
3. **T-1 Day**: Final reminder - "Your appointment is tomorrow"
4. **Post-Appointment**: "Thank you for attending. Your next appointment is..."

### SMS Template Example
```
Hi [PATIENT_NAME],

Your [APPOINTMENT_TYPE] appointment is scheduled for:
📅 [APPOINTMENT_DATE]
🏥 [LOCATION]

Please arrive 15 minutes early.
Reply CONFIRM to confirm or RESCHEDULE to change the date.

Code: [PATIENT_CODE]
```

### Scheduling Algorithm
```
1. Every day at 2 AM (system maintenance window):
   - Query appointments from next 1-7 days
   - Check if reminder should be sent based on template rules
   - Verify phone number is valid
   - Queue SMS job in Bull Queue / Task Queue
   
2. Queue processes jobs:
   - Send SMS via Twilio/SMS Provider API
   - Log status in database
   - Retry failed messages (max 3 attempts)
   - Notify admin if critical failures
```

---

## 5. AUTHENTICATION & SECURITY

### User Roles
1. **Patient** - View own appointments and metrics
2. **Staff** - Create/manage appointments, record metrics
3. **Administrator** - Manage all patients, staff, settings, analytics
4. **SMS Gateway Admin** - Manage SMS templates and logs

### Security Measures
- **JWT Tokens** with 24-hour expiration for staff/admin
- **Password Hashing** - bcrypt with salt rounds 12+
- **Phone Number Verification** - OTP before SMS sending
- **Data Encryption** - HIPAA-compliant encryption for patient data
- **Audit Logging** - All patient data access logged
- **Rate Limiting** - API rate limits to prevent abuse
- **CORS** - Restrict to approved domains only

---

## 6. DEPLOYMENT ARCHITECTURE

### Infrastructure Setup (AWS/Azure/Self-Hosted)
```
┌─────────────┐
│  Web UI     │ (React Dashboard)
└──────┬──────┘
       │ HTTPS
┌──────▼──────────────────────┐
│   API Gateway               │
│   (Rate Limiting, Auth)     │
└──────┬──────────────────────┘
       │
   ┌───┴────────────────────────────┐
   │                                │
┌──▼─────────────┐     ┌──────────▼──┐
│ REST API       │     │ WebSocket    │
│ (Appointments  │     │ (Real-time   │
│  Health Metrics│     │  Updates)    │
│  Patients)     │     └──────────────┘
└──┬──────────┬──┘
   │          │
   │     ┌────▼──────────────┐
   │     │ Job Scheduler     │
   │     │ (Reminder Service)│
   │     └────┬──────────────┘
   │          │
   │     ┌────▼──────────────┐
   │     │ SMS Gateway       │
   │     │ (Twilio/AWS SNS)  │
   │     └───────────────────┘
   │
┌──▼─────────────┐
│ PostgreSQL     │
│ (Primary DB)   │
└────────────────┘

┌──────────────┐
│ Redis        │
│ (Cache,      │
│  Job Queue)  │
└──────────────┘
```

---

## 7. IMPLEMENTATION ROADMAP

### Phase 1: MVP (Week 1-2)
- [ ] Basic patient CRUD
- [ ] Appointment scheduling
- [ ] SMS notification queue
- [ ] Simple dashboard UI
- [ ] SMS template system

### Phase 2: Core Features (Week 3-4)
- [ ] Health metrics recording
- [ ] Automated reminder scheduling
- [ ] Patient authentication
- [ ] Appointment status tracking
- [ ] Basic analytics

### Phase 3: Enhancement (Week 5-6)
- [ ] Mobile app (React Native)
- [ ] Advanced reporting
- [ ] Multi-language support
- [ ] SMS response handling (CONFIRM/RESCHEDULE)
- [ ] Integration with hospital systems (HL7/FHIR)

### Phase 4: Production (Week 7+)
- [ ] HIPAA compliance audit
- [ ] Load testing
- [ ] Disaster recovery planning
- [ ] Staff training materials
- [ ] Deployment to production

---

## 8. TECHNOLOGY STACK RECOMMENDATION

### Backend Option A: Node.js (Recommended for rapid development)
- **Runtime**: Node.js 18+
- **Framework**: Express.js or NestJS
- **Database**: PostgreSQL + Prisma ORM
- **Task Queue**: Bull (Redis-backed)
- **SMS**: Twilio SDK
- **Deployment**: Docker + Kubernetes or AWS ECS

### Backend Option B: Python (For healthcare integration)
- **Framework**: FastAPI or Django
- **Database**: PostgreSQL + SQLAlchemy
- **Task Queue**: Celery + Redis
- **SMS**: Twilio SDK
- **Deployment**: Docker + Railway or Heroku

### Frontend
- **React 18+** with TypeScript
- **Tailwind CSS** for styling
- **React Query** for data fetching
- **Zustand** for state management
- **React Hook Form** for forms
- **Framer Motion** for animations

---

## 9. SAMPLE ENDPOINTS WITH REQUEST/RESPONSE

### Create Patient
```
POST /api/patients
Content-Type: application/json

{
  "patient_code": "PAT-2024-0001",
  "first_name": "Jean",
  "last_name": "Nkosi",
  "phone_number": "+237677123456",
  "date_of_birth": "1985-03-15",
  "gender": "M",
  "conditions": {
    "hiv": true,
    "tb": false
  }
}

RESPONSE: 201 Created
{
  "id": "uuid-here",
  "patient_code": "PAT-2024-0001",
  "created_at": "2024-03-31T10:30:00Z"
}
```

### Schedule Appointment
```
POST /api/appointments
Content-Type: application/json

{
  "patient_id": "uuid-here",
  "appointment_type": "hiv_trimester",
  "scheduled_date": "2024-06-15T09:00:00Z",
  "location": "Clinic A, Room 5"
}

RESPONSE: 201 Created
{
  "id": "appointment-uuid",
  "status": "scheduled",
  "reminder_scheduled_dates": ["2024-06-08", "2024-06-13", "2024-06-14"]
}
```

### Record Health Metric
```
POST /api/metrics/patient-uuid
Content-Type: application/json

{
  "metric_type": "hiv_viral_load",
  "metric_value": "45",
  "unit": "copies/mL",
  "measurement_date": "2024-03-31",
  "normal_range": "<50",
  "status": "normal"
}

RESPONSE: 201 Created
{
  "id": "metric-uuid",
  "created_at": "2024-03-31T10:30:00Z"
}
```

---

## 10. COMPLIANCE & BEST PRACTICES

### Data Privacy (HIPAA/GDPR-Equivalent)
- Encrypt patient data at rest (AES-256)
- Encrypt data in transit (TLS 1.3)
- Implement access logging
- Data retention policies (define per regulation)
- Right to deletion (GDPR compliance)

### Reliability
- **Uptime Target**: 99.5% (healthcare-grade)
- **Backup Strategy**: Daily backups, 30-day retention
- **Disaster Recovery**: RTO 1 hour, RPO 15 minutes
- **Monitoring**: CloudWatch/DataDog for system health

### Testing
- **Unit Tests**: 80%+ coverage (Jest/pytest)
- **Integration Tests**: Full workflow testing
- **SMS Testing**: Use Twilio sandbox before production
- **Load Testing**: k6 or Apache JMeter (target 1000 concurrent users)

---

## Next Steps

1. Choose technology stack (Node.js vs Python backend)
2. Set up development environment
3. Create database schema and migrations
4. Build core APIs (Patient, Appointment, Metrics)
5. Implement SMS scheduling service
6. Develop React dashboard
7. Test SMS workflow end-to-end
8. Deploy to staging environment
9. Conduct security audit
10. Launch to production

---

**Estimated Timeline**: 6-8 weeks for production-ready system
**Team Size**: 2-3 developers (backend), 1-2 developers (frontend), 1 DevOps engineer
**Total Cost**: $15,000-$40,000 (depending on SMS volume and infrastructure)
