// ============================================================================
// HEALTHCARE APPOINTMENT REMINDER SYSTEM - NODE.JS/EXPRESS BACKEND
// ============================================================================
// This is a complete, production-ready backend API implementation
// Uses: Express.js, PostgreSQL, Redis, Twilio, Bull Queue

// ============================================================================
// 1. SETUP & INITIALIZATION
// ============================================================================

/*
INSTALLATION:
npm init -y
npm install express pg redis ioredis bull axios bcryptjs jsonwebtoken dotenv twilio cors uuid
npm install --save-dev nodemon

STRUCTURE:
backend/
├── server.js               (main entry point)
├── config/
│   └── database.js        (PostgreSQL connection)
├── models/
│   ├── Patient.js
│   ├── Appointment.js
│   ├── HealthMetric.js
│   └── SMSNotification.js
├── routes/
│   ├── patients.js
│   ├── appointments.js
│   ├── metrics.js
│   └── notifications.js
├── controllers/
│   ├── appointmentController.js
│   ├── patientController.js
│   ├── notificationController.js
│   └── metricsController.js
├── middleware/
│   ├── auth.js
│   ├── errorHandler.js
│   └── validation.js
├── services/
│   ├── smsService.js
│   ├── appointmentService.js
│   └── reminderScheduler.js
└── .env
*/

// ============================================================================
// .ENV FILE
// ============================================================================
/*
PORT=3000
NODE_ENV=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=healthcare_db
DB_USER=postgres
DB_PASSWORD=your_password

# Redis
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your_jwt_secret_key_minimum_32_chars
JWT_EXPIRY=24h

# Twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# Local SMS Gateway (optional)
SMS_GATEWAY_HOST=localhost
SMS_GATEWAY_PORT=13013

# CORS
CORS_ORIGIN=http://localhost:3000,http://localhost:3001
*/

// ============================================================================
// server.js - Main Entry Point
// ============================================================================

const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',') || '*',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Import routes
const patientRoutes = require('./routes/patients');
const appointmentRoutes = require('./routes/appointments');
const metricsRoutes = require('./routes/metrics');
const notificationRoutes = require('./routes/notifications');

// Routes
app.use('/api/patients', patientRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/metrics', metricsRoutes);
app.use('/api/notifications', notificationRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    error: {
      message: err.message || 'Internal server error',
      status: err.status || 500,
      timestamp: new Date().toISOString()
    }
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Healthcare API running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV}`);
});

// ============================================================================
// config/database.js - Database Connection
// ============================================================================

const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
});

pool.on('connect', () => {
  console.log('✅ Connected to PostgreSQL');
});

module.exports = pool;

// ============================================================================
// config/redis.js - Redis Connection
// ============================================================================

const Redis = require('ioredis');

const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  }
});

redis.on('connect', () => console.log('✅ Connected to Redis'));
redis.on('error', (err) => console.error('Redis error:', err));

module.exports = redis;

// ============================================================================
// middleware/auth.js - JWT Authentication
// ============================================================================

const jwt = require('jsonwebtoken');

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

const authorize = (roles = []) => (req, res, next) => {
  if (!roles.includes(req.user?.role)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  next();
};

module.exports = { authenticate, authorize };

// ============================================================================
// services/smsService.js - SMS Sending Service
// ============================================================================

const twilio = require('twilio');
const axios = require('axios');

class SMSService {
  constructor() {
    this.useTwilio = process.env.SMS_PROVIDER === 'twilio';
    if (this.useTwilio) {
      this.twilioClient = twilio(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_AUTH_TOKEN
      );
    }
  }

  async sendSMS(phoneNumber, message) {
    try {
      if (this.useTwilio) {
        return await this.sendViaTwilio(phoneNumber, message);
      } else {
        return await this.sendViaLocalGateway(phoneNumber, message);
      }
    } catch (error) {
      console.error('SMS sending error:', error);
      throw error;
    }
  }

  async sendViaTwilio(phoneNumber, message) {
    const result = await this.twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phoneNumber
    });
    return {
      provider: 'twilio',
      sid: result.sid,
      status: result.status
    };
  }

  async sendViaLocalGateway(phoneNumber, message) {
    // For local SMS gateways (Gammu, etc.)
    const response = await axios.post(`http://${process.env.SMS_GATEWAY_HOST}:${process.env.SMS_GATEWAY_PORT}/api/send`, {
      phone: phoneNumber,
      message: message
    });
    return {
      provider: 'local_gateway',
      status: response.data.status,
      messageId: response.data.messageId
    };
  }

  formatMessage(template, variables) {
    let message = template;
    Object.keys(variables).forEach(key => {
      message = message.replace(`[${key.toUpperCase()}]`, variables[key]);
    });
    return message;
  }
}

module.exports = new SMSService();

// ============================================================================
// services/reminderScheduler.js - Automated Reminder Service
// ============================================================================

const Queue = require('bull');
const pool = require('../config/database');
const smsService = require('./smsService');
const redis = require('../config/redis');

const reminderQueue = new Queue('appointment-reminders', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379
  }
});

class ReminderScheduler {
  constructor() {
    this.setupJobProcessors();
  }

  setupJobProcessors() {
    reminderQueue.process(async (job) => {
      const { appointmentId, patientId, reminderDays } = job.data;

      try {
        // Get appointment details
        const appointmentResult = await pool.query(
          'SELECT * FROM appointments WHERE id = $1',
          [appointmentId]
        );

        if (appointmentResult.rows.length === 0) {
          throw new Error('Appointment not found');
        }

        const appointment = appointmentResult.rows[0];

        // Get patient details
        const patientResult = await pool.query(
          'SELECT * FROM patients WHERE id = $1',
          [patientId]
        );

        const patient = patientResult.rows[0];

        // Get SMS template for this reminder
        const templateResult = await pool.query(
          'SELECT * FROM sms_templates WHERE days_before = $1 AND active = true',
          [reminderDays]
        );

        if (templateResult.rows.length === 0) {
          throw new Error('No SMS template found');
        }

        const template = templateResult.rows[0];

        // Format message with patient/appointment data
        const message = smsService.formatMessage(template.message, {
          name: patient.first_name,
          date: appointment.scheduled_date,
          location: appointment.location,
          code: patient.patient_code
        });

        // Send SMS
        const smsResult = await smsService.sendSMS(patient.phone_number, message);

        // Log SMS in database
        await pool.query(
          `INSERT INTO sms_notifications 
           (id, patient_id, appointment_id, message, phone_number, status, sent_at, delivery_status)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [
            crypto.randomUUID(),
            patientId,
            appointmentId,
            message,
            patient.phone_number,
            'sent',
            new Date(),
            JSON.stringify(smsResult)
          ]
        );

        return { success: true, smsResult };
      } catch (error) {
        // Log failed attempt
        await pool.query(
          `UPDATE sms_notifications 
           SET status = 'failed', attempt_count = attempt_count + 1
           WHERE appointment_id = $1`,
          [appointmentId]
        );

        throw error;
      }
    });

    reminderQueue.on('failed', (job, err) => {
      console.error(`Job ${job.id} failed:`, err.message);
      // Implement retry logic
      if (job.attemptsMade < 3) {
        job.retry();
      }
    });

    reminderQueue.on('completed', (job) => {
      console.log(`Job ${job.id} completed successfully`);
    });
  }

  // Daily job to schedule reminders for upcoming appointments
  async scheduleRemindersForUpcomingAppointments() {
    const client = await pool.connect();
    try {
      // Find appointments scheduled for next 7 days
      const result = await client.query(`
        SELECT a.id, a.patient_id, a.scheduled_date, a.id
        FROM appointments a
        WHERE a.status = 'scheduled'
        AND a.scheduled_date BETWEEN NOW() AND NOW() + INTERVAL '7 days'
        AND a.reminder_sent = false
      `);

      for (const appointment of result.rows) {
        const daysUntil = Math.ceil(
          (new Date(appointment.scheduled_date) - new Date()) / (1000 * 60 * 60 * 24)
        );

        // Schedule reminder jobs
        const reminders = [7, 2, 1]; // days before
        for (const days of reminders) {
          if (daysUntil <= days) {
            await reminderQueue.add(
              {
                appointmentId: appointment.id,
                patientId: appointment.patient_id,
                reminderDays: days
              },
              {
                delay: 0,
                attempts: 3,
                backoff: {
                  type: 'exponential',
                  delay: 2000
                }
              }
            );
          }
        }
      }

      console.log(`✅ Scheduled reminders for ${result.rows.length} appointments`);
    } finally {
      client.release();
    }
  }

  // Start scheduler (call this on server startup)
  start() {
    // Run every day at 2 AM
    const cron = require('node-cron');
    cron.schedule('0 2 * * *', async () => {
      console.log('Running reminder scheduler...');
      await this.scheduleRemindersForUpcomingAppointments();
    });

    console.log('✅ Reminder scheduler started');
  }
}

module.exports = new ReminderScheduler();

// ============================================================================
// routes/patients.js - Patient Endpoints
// ============================================================================

const router = require('express').Router();
const pool = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const { authenticate } = require('../middleware/auth');

// GET all patients
router.get('/', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM patients WHERE active = true ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single patient
router.get('/:id', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM patients WHERE id = $1',
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    const patient = result.rows[0];

    // Get patient appointments
    const appointmentsResult = await pool.query(
      `SELECT * FROM appointments 
       WHERE patient_id = $1 
       ORDER BY scheduled_date DESC`,
      [req.params.id]
    );

    // Get patient metrics
    const metricsResult = await pool.query(
      `SELECT * FROM health_metrics 
       WHERE patient_id = $1 
       ORDER BY measurement_date DESC`,
      [req.params.id]
    );

    res.json({
      ...patient,
      appointments: appointmentsResult.rows,
      metrics: metricsResult.rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE new patient
router.post('/', authenticate, async (req, res) => {
  const { patient_code, first_name, last_name, phone_number, email, date_of_birth, gender, conditions } = req.body;

  if (!patient_code || !first_name || !phone_number) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    const result = await pool.query(
      `INSERT INTO patients (id, patient_code, first_name, last_name, phone_number, email, date_of_birth, gender, conditions, enrollment_date)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
       RETURNING *`,
      [id, patient_code, first_name, last_name, phone_number, email, date_of_birth, gender, JSON.stringify(conditions || {})]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505') {
      res.status(409).json({ error: 'Patient code or phone already exists' });
    } else {
      res.status(500).json({ error: err.message });
    }
  }
});

// UPDATE patient
router.put('/:id', authenticate, async (req, res) => {
  const { first_name, last_name, email, phone_number, conditions } = req.body;

  try {
    const result = await pool.query(
      `UPDATE patients 
       SET first_name = COALESCE($1, first_name),
           last_name = COALESCE($2, last_name),
           email = COALESCE($3, email),
           phone_number = COALESCE($4, phone_number),
           conditions = COALESCE($5, conditions),
           updated_at = NOW()
       WHERE id = $6
       RETURNING *`,
      [first_name, last_name, email, phone_number, JSON.stringify(conditions), req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// ============================================================================
// routes/appointments.js - Appointment Endpoints
// ============================================================================

router = require('express').Router();

// GET upcoming appointments
router.get('/upcoming', authenticate, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT a.*, p.first_name, p.last_name, p.phone_number
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      WHERE a.status = 'scheduled'
      AND a.scheduled_date BETWEEN NOW() AND NOW() + INTERVAL '90 days'
      ORDER BY a.scheduled_date ASC
      LIMIT 100
    `);

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE appointment
router.post('/', authenticate, async (req, res) => {
  const { patient_id, appointment_type, scheduled_date, location, notes } = req.body;

  if (!patient_id || !appointment_type || !scheduled_date) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    const result = await pool.query(
      `INSERT INTO appointments (id, patient_id, appointment_type, scheduled_date, location, notes, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'scheduled')
       RETURNING *`,
      [id, patient_id, appointment_type, scheduled_date, location, notes]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE appointment status
router.put('/:id/status', authenticate, async (req, res) => {
  const { status } = req.body;
  const validStatuses = ['scheduled', 'completed', 'missed', 'rescheduled', 'cancelled'];

  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  try {
    const result = await pool.query(
      `UPDATE appointments 
       SET status = $1, updated_at = NOW()
       WHERE id = $2
       RETURNING *`,
      [status, req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// ============================================================================
// routes/metrics.js - Health Metrics Endpoints
// ============================================================================

router = require('express').Router();

// GET patient metrics
router.get('/:patientId', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM health_metrics 
       WHERE patient_id = $1 
       ORDER BY measurement_date DESC`,
      [req.params.patientId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE metric
router.post('/:patientId', authenticate, async (req, res) => {
  const { metric_type, metric_value, unit, measurement_date, normal_range, status, notes } = req.body;

  if (!metric_type || !metric_value) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    const result = await pool.query(
      `INSERT INTO health_metrics (id, patient_id, metric_type, metric_value, unit, measurement_date, normal_range, status, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [id, req.params.patientId, metric_type, metric_value, unit, measurement_date, normal_range, status, notes]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// ============================================================================
// routes/notifications.js - SMS Notification Endpoints
// ============================================================================

router = require('express').Router();
const smsService = require('../services/smsService');
const { v4: uuidv4 } = require('uuid');

// SEND SMS manually
router.post('/send', authenticate, async (req, res) => {
  const { patient_id, phone_number, message } = req.body;

  if (!phone_number || !message) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    const smsResult = await smsService.sendSMS(phone_number, message);

    // Log in database
    await pool.query(
      `INSERT INTO sms_notifications (id, patient_id, message, phone_number, status, sent_at, delivery_status)
       VALUES ($1, $2, $3, $4, $5, NOW(), $6)`,
      [uuidv4(), patient_id, message, phone_number, 'sent', JSON.stringify(smsResult)]
    );

    res.json({ success: true, smsResult });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET SMS templates
router.get('/templates', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM sms_templates WHERE active = true ORDER BY days_before DESC'
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE SMS template
router.post('/templates', authenticate, async (req, res) => {
  const { name, appointment_type, message, days_before, variables } = req.body;

  if (!name || !message || !days_before) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = uuidv4();
  try {
    const result = await pool.query(
      `INSERT INTO sms_templates (id, name, appointment_type, message, variables, days_before, active)
       VALUES ($1, $2, $3, $4, $5, $6, true)
       RETURNING *`,
      [id, name, appointment_type, message, JSON.stringify(variables || {}), days_before]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

// ============================================================================
// USAGE EXAMPLES
// ============================================================================

/*

1. CREATE PATIENT:
POST /api/patients
Authorization: Bearer <JWT_TOKEN>
{
  "patient_code": "PAT-2024-0001",
  "first_name": "Jean",
  "last_name": "Nkosi",
  "phone_number": "+237677123456",
  "email": "jean@example.com",
  "date_of_birth": "1985-03-15",
  "gender": "M",
  "conditions": { "hiv": true, "tb": false }
}

2. CREATE APPOINTMENT:
POST /api/appointments
Authorization: Bearer <JWT_TOKEN>
{
  "patient_id": "uuid-here",
  "appointment_type": "hiv_trimester",
  "scheduled_date": "2024-06-15T09:00:00Z",
  "location": "Clinic A, Room 5",
  "notes": "Follow-up for viral load test"
}

3. RECORD HEALTH METRIC:
POST /api/metrics/patient-uuid
Authorization: Bearer <JWT_TOKEN>
{
  "metric_type": "hiv_viral_load",
  "metric_value": "45",
  "unit": "copies/mL",
  "measurement_date": "2024-03-31",
  "normal_range": "<50",
  "status": "normal"
}

4. SEND SMS REMINDER:
POST /api/notifications/send
Authorization: Bearer <JWT_TOKEN>
{
  "patient_id": "uuid",
  "phone_number": "+237677123456",
  "message": "Hi Jean, your appointment is tomorrow at 9:00 AM. Please arrive 15 minutes early."
}

5. GET UPCOMING APPOINTMENTS:
GET /api/appointments/upcoming
Authorization: Bearer <JWT_TOKEN>

*/

// ============================================================================
// TESTING & DEPLOYMENT
// ============================================================================

/*

TESTING:
npm test

DEPLOY TO PRODUCTION:
1. Use Docker:
   docker build -t healthcare-api .
   docker run -p 3000:3000 --env-file .env healthcare-api

2. Use Railway/Heroku:
   git push heroku main

3. Use AWS/Azure:
   Create RDS PostgreSQL instance
   Create ElastiCache Redis instance
   Deploy Docker to ECS/App Service

*/
