import React, { useState, useEffect } from 'react';
import { Calendar, AlertCircle, Clock, User, Activity, Phone, CheckCircle, XCircle, MessageSquare, Plus, Edit2, Trash2, Eye, Settings } from 'lucide-react';

const HealthcareAppointmentDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [patients, setPatients] = useState([
    {
      id: 1,
      code: 'PAT-2024-0001',
      name: 'Jean Nkosi',
      phone: '+237677123456',
      conditions: ['HIV', 'TB'],
      lastAppointment: '2024-01-15',
      nextAppointment: '2024-04-15',
      status: 'active',
      metrics: {
        hivViralLoad: { value: '45 copies/mL', lastTest: '2024-01-15', status: 'normal' },
        tbStatus: { value: 'Controlled', lastTest: '2024-01-20', status: 'normal' },
      }
    },
    {
      id: 2,
      code: 'PAT-2024-0002',
      name: 'Amara Diallo',
      phone: '+237688234567',
      conditions: ['HIV'],
      lastAppointment: '2024-02-10',
      nextAppointment: '2024-05-10',
      status: 'active',
      metrics: {
        hivViralLoad: { value: '85 copies/mL', lastTest: '2024-02-10', status: 'elevated' },
      }
    },
    {
      id: 3,
      code: 'PAT-2024-0003',
      name: 'Carlos Mensah',
      phone: '+237699345678',
      conditions: ['HIV'],
      lastAppointment: '2024-03-01',
      nextAppointment: '2024-06-01',
      status: 'overdue',
      metrics: {
        hivViralLoad: { value: '2,450 copies/mL', lastTest: '2024-01-10', status: 'critical' },
      }
    }
  ]);

  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [smsTemplates] = useState([
    { id: 1, days: 7, text: 'Hi [NAME], your appointment is in 7 days on [DATE]. Please confirm.' },
    { id: 2, days: 2, text: 'Reminder: Your appointment is in 2 days at [LOCATION].' },
    { id: 3, days: 1, text: 'Your appointment is tomorrow at [TIME]. Please arrive 15 minutes early.' }
  ]);

  const upcomingAppointments = patients
    .filter(p => new Date(p.nextAppointment) > new Date())
    .sort((a, b) => new Date(a.nextAppointment) - new Date(b.nextAppointment));

  const overdueAppointments = patients.filter(p => p.status === 'overdue');

  const getMetricColor = (status) => {
    return status === 'normal' ? 'text-green-600' : status === 'elevated' ? 'text-yellow-600' : 'text-red-600';
  };

  const getMetricBgColor = (status) => {
    return status === 'normal' ? 'bg-green-50' : status === 'elevated' ? 'bg-yellow-50' : 'bg-red-50';
  };

  const sendReminders = (appointmentId) => {
    alert(`Reminders scheduled for appointment ${appointmentId}`);
    // In real app, this would call the backend API
  };

  return (
    <div style={{
      '--medical-primary': '#0f172a',
      '--medical-accent': '#dc2626',
      '--medical-success': '#16a34a',
      '--medical-warning': '#ea580c',
      backgroundColor: '#f9fafb'
    }}>
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
          color: #1f2937;
        }

        .dashboard-container {
          max-width: 1600px;
          margin: 0 auto;
          padding: 20px;
        }

        /* Header */
        .header {
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          color: white;
          padding: 40px 30px;
          border-radius: 12px;
          margin-bottom: 30px;
          box-shadow: 0 10px 30px rgba(0,0,0,0.1);
          position: relative;
          overflow: hidden;
        }

        .header::before {
          content: '';
          position: absolute;
          top: -50%;
          right: -10%;
          width: 400px;
          height: 400px;
          background: rgba(255,255,255,0.05);
          border-radius: 50%;
          filter: blur(40px);
        }

        .header-content {
          position: relative;
          z-index: 1;
        }

        .header h1 {
          font-size: 32px;
          font-weight: 700;
          margin-bottom: 8px;
          letter-spacing: -0.5px;
        }

        .header p {
          font-size: 15px;
          opacity: 0.9;
          color: #e2e8f0;
        }

        .header-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-top: 25px;
        }

        .stat-card {
          background: rgba(255,255,255,0.1);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255,255,255,0.2);
          padding: 15px;
          border-radius: 8px;
        }

        .stat-number {
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .stat-label {
          font-size: 13px;
          opacity: 0.85;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        /* Tabs */
        .tabs {
          display: flex;
          gap: 10px;
          margin-bottom: 30px;
          border-bottom: 2px solid #e5e7eb;
        }

        .tab-button {
          padding: 12px 20px;
          border: none;
          background: none;
          font-size: 15px;
          font-weight: 500;
          cursor: pointer;
          color: #6b7280;
          border-bottom: 3px solid transparent;
          transition: all 0.3s ease;
          position: relative;
        }

        .tab-button.active {
          color: #0f172a;
          border-bottom-color: #dc2626;
        }

        .tab-button:hover {
          color: #1f2937;
        }

        /* Cards Grid */
        .cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 20px;
          margin-bottom: 30px;
        }

        .card {
          background: white;
          border-radius: 12px;
          padding: 24px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.06);
          border: 1px solid #e5e7eb;
          transition: all 0.3s ease;
          position: relative;
        }

        .card:hover {
          box-shadow: 0 8px 20px rgba(0,0,0,0.1);
          transform: translateY(-2px);
        }

        .card-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 16px;
        }

        .card-title {
          font-size: 16px;
          font-weight: 600;
          color: #1f2937;
        }

        .card-status {
          display: inline-block;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .status-active {
          background: #dcfce7;
          color: #166534;
        }

        .status-overdue {
          background: #fee2e2;
          color: #991b1b;
        }

        .status-warning {
          background: #fef3c7;
          color: #92400e;
        }

        /* Patient Card */
        .patient-card {
          border-left: 4px solid #0f172a;
        }

        .patient-info {
          display: flex;
          gap: 12px;
          margin-bottom: 16px;
        }

        .patient-avatar {
          width: 48px;
          height: 48px;
          border-radius: 8px;
          background: linear-gradient(135deg, #0f172a, #1e293b);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 18px;
        }

        .patient-details {
          flex: 1;
        }

        .patient-name {
          font-size: 15px;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 4px;
        }

        .patient-code {
          font-size: 12px;
          color: #6b7280;
          font-family: 'Monaco', monospace;
        }

        .info-row {
          display: flex;
          justify-content: space-between;
          padding: 12px 0;
          border-bottom: 1px solid #f3f4f6;
          font-size: 13px;
        }

        .info-row:last-child {
          border-bottom: none;
        }

        .info-label {
          color: #6b7280;
          font-weight: 500;
        }

        .info-value {
          color: #1f2937;
          font-weight: 600;
        }

        /* Metrics */
        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
          gap: 12px;
          margin-top: 16px;
        }

        .metric-box {
          padding: 12px;
          border-radius: 8px;
          font-size: 12px;
        }

        .metric-label {
          opacity: 0.75;
          margin-bottom: 4px;
          font-weight: 500;
        }

        .metric-value {
          font-weight: 700;
          font-size: 14px;
        }

        /* Alerts */
        .alert {
          padding: 16px;
          border-radius: 8px;
          display: flex;
          gap: 12px;
          margin-bottom: 16px;
          align-items: flex-start;
        }

        .alert-critical {
          background: #fee2e2;
          border: 1px solid #fecaca;
          color: #7f1d1d;
        }

        .alert-warning {
          background: #fef3c7;
          border: 1px solid #fde68a;
          color: #78350f;
        }

        /* Action Buttons */
        .action-buttons {
          display: flex;
          gap: 8px;
          margin-top: 16px;
          justify-content: flex-end;
        }

        .btn {
          padding: 8px 16px;
          border: none;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .btn-primary {
          background: #dc2626;
          color: white;
        }

        .btn-primary:hover {
          background: #b91c1c;
          box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
        }

        .btn-secondary {
          background: #e5e7eb;
          color: #1f2937;
        }

        .btn-secondary:hover {
          background: #d1d5db;
        }

        .btn-sm {
          padding: 6px 12px;
          font-size: 12px;
        }

        /* List */
        .list-container {
          background: white;
          border-radius: 12px;
          border: 1px solid #e5e7eb;
          overflow: hidden;
        }

        .list-item {
          padding: 16px;
          border-bottom: 1px solid #f3f4f6;
          display: flex;
          justify-content: space-between;
          align-items: center;
          transition: background 0.2s ease;
        }

        .list-item:hover {
          background: #f9fafb;
        }

        .list-item:last-child {
          border-bottom: none;
        }

        .list-info {
          flex: 1;
        }

        .list-title {
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 4px;
        }

        .list-meta {
          font-size: 13px;
          color: #6b7280;
        }

        /* Modal */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .modal {
          background: white;
          border-radius: 12px;
          padding: 32px;
          max-width: 600px;
          width: 90%;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        .modal-header {
          font-size: 22px;
          font-weight: 700;
          color: #0f172a;
          margin-bottom: 24px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .modal-close {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          color: #6b7280;
        }

        .form-group {
          margin-bottom: 20px;
        }

        .form-label {
          display: block;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 8px;
          font-size: 14px;
        }

        .form-input {
          width: 100%;
          padding: 10px 12px;
          border: 1px solid #d1d5db;
          border-radius: 6px;
          font-size: 14px;
          font-family: inherit;
        }

        .form-input:focus {
          outline: none;
          border-color: #dc2626;
          box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1);
        }

        .empty-state {
          text-align: center;
          padding: 60px 20px;
          color: #6b7280;
        }

        .empty-state-icon {
          font-size: 48px;
          margin-bottom: 16px;
          opacity: 0.5;
        }

        .empty-state-title {
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 8px;
        }
      `}</style>

      <div className="dashboard-container">
        {/* Header */}
        <div className="header">
          <div className="header-content">
            <h1>🏥 Patient Appointment Manager</h1>
            <p>Healthcare appointment reminders and patient health tracking system</p>
            
            <div className="header-stats">
              <div className="stat-card">
                <div className="stat-number">{patients.length}</div>
                <div className="stat-label">Total Patients</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{upcomingAppointments.length}</div>
                <div className="stat-label">Upcoming Appts</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{overdueAppointments.length}</div>
                <div className="stat-label">Overdue</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">{smsTemplates.length}</div>
                <div className="stat-label">SMS Templates</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="tabs">
          <button className={`tab-button ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>
            <Calendar size={16} style={{marginRight: '6px'}} /> Dashboard
          </button>
          <button className={`tab-button ${activeTab === 'patients' ? 'active' : ''}`} onClick={() => setActiveTab('patients')}>
            <User size={16} style={{marginRight: '6px'}} /> Patients
          </button>
          <button className={`tab-button ${activeTab === 'templates' ? 'active' : ''}`} onClick={() => setActiveTab('templates')}>
            <MessageSquare size={16} style={{marginRight: '6px'}} /> SMS Templates
          </button>
          <button className={`tab-button ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
            <Settings size={16} style={{marginRight: '6px'}} /> Settings
          </button>
        </div>

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <>
            {/* Alerts */}
            {overdueAppointments.length > 0 && (
              <div style={{marginBottom: '20px'}}>
                {overdueAppointments.map(p => (
                  <div key={p.id} className="alert alert-critical">
                    <AlertCircle size={20} style={{flexShrink: 0}} />
                    <div>
                      <strong>{p.name}</strong> ({p.code}) has overdue appointments. Last appointment: {p.lastAppointment}
                    </div>
                  </div>
                ))}
              </div>
            )}

            <h2 style={{fontSize: '20px', fontWeight: '700', color: '#0f172a', marginBottom: '16px'}}>
              📅 Upcoming Appointments (Next 90 Days)
            </h2>
            <div className="cards-grid">
              {upcomingAppointments.length > 0 ? (
                upcomingAppointments.map(patient => (
                  <div key={patient.id} className="card">
                    <div className="card-header">
                      <div>
                        <div className="card-title">{patient.name}</div>
                        <div style={{fontSize: '12px', color: '#6b7280', marginTop: '4px'}}>{patient.code}</div>
                      </div>
                      <span className={`card-status status-active`}>Active</span>
                    </div>

                    <div className="info-row" style={{padding: '8px 0'}}>
                      <span className="info-label">📞 Contact</span>
                      <span className="info-value">{patient.phone}</span>
                    </div>

                    <div className="info-row" style={{padding: '8px 0'}}>
                      <span className="info-label">📋 Type</span>
                      <span className="info-value">{patient.conditions.join(', ')}</span>
                    </div>

                    <div className="info-row" style={{padding: '8px 0'}}>
                      <span className="info-label">📅 Next Appt</span>
                      <span className="info-value">{patient.nextAppointment}</span>
                    </div>

                    <div style={{marginTop: '12px', padding: '12px', background: '#f0fdf4', borderRadius: '6px'}}>
                      <div style={{fontSize: '12px', fontWeight: '600', color: '#166534', marginBottom: '4px'}}>HIV Viral Load</div>
                      <div style={{fontSize: '14px', fontWeight: '700', color: '#16a34a'}}>{patient.metrics.hivViralLoad.value}</div>
                      <div style={{fontSize: '11px', color: '#6b7280', marginTop: '2px'}}>Last: {patient.metrics.hivViralLoad.lastTest}</div>
                    </div>

                    <div className="action-buttons">
                      <button className="btn btn-primary btn-sm" onClick={() => sendReminders(patient.id)}>
                        <MessageSquare size={14} /> Send Reminders
                      </button>
                      <button className="btn btn-secondary btn-sm">
                        <Edit2 size={14} /> Edit
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">
                  <div className="empty-state-icon">📭</div>
                  <div className="empty-state-title">No upcoming appointments</div>
                </div>
              )}
            </div>
          </>
        )}

        {/* Patients Tab */}
        {activeTab === 'patients' && (
          <>
            <div style={{marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <h2 style={{fontSize: '20px', fontWeight: '700', color: '#0f172a'}}>All Patients</h2>
              <button className="btn btn-primary" onClick={() => setShowModal(true)}>
                <Plus size={16} /> New Patient
              </button>
            </div>

            <div className="list-container">
              {patients.map(patient => (
                <div key={patient.id} className="list-item">
                  <div className="list-info" onClick={() => setSelectedPatient(patient)}>
                    <div className="list-title">{patient.name}</div>
                    <div className="list-meta">{patient.code} • {patient.phone} • Conditions: {patient.conditions.join(', ')}</div>
                  </div>
                  <div style={{display: 'flex', gap: '8px'}}>
                    <span className={`card-status ${patient.status === 'active' ? 'status-active' : 'status-overdue'}`}>
                      {patient.status === 'active' ? '✓ Active' : '⚠ Overdue'}
                    </span>
                    <button className="btn btn-secondary btn-sm">
                      <Eye size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* SMS Templates Tab */}
        {activeTab === 'templates' && (
          <>
            <h2 style={{fontSize: '20px', fontWeight: '700', color: '#0f172a', marginBottom: '16px'}}>SMS Templates</h2>
            <div className="cards-grid">
              {smsTemplates.map(template => (
                <div key={template.id} className="card">
                  <div className="card-header">
                    <div>
                      <div className="card-title">Send {template.days} days before</div>
                    </div>
                    <span className="card-status status-active">Active</span>
                  </div>
                  <div style={{padding: '12px', background: '#f3f4f6', borderRadius: '6px', fontSize: '13px', color: '#1f2937', marginBottom: '16px'}}>
                    "{template.text}"
                  </div>
                  <div className="action-buttons">
                    <button className="btn btn-secondary btn-sm">
                      <Edit2 size={14} /> Edit
                    </button>
                    <button className="btn btn-secondary btn-sm">
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <>
            <h2 style={{fontSize: '20px', fontWeight: '700', color: '#0f172a', marginBottom: '16px'}}>System Settings</h2>
            <div className="card" style={{maxWidth: '600px'}}>
              <div className="form-group">
                <label className="form-label">SMS Provider</label>
                <select className="form-input">
                  <option>Twilio</option>
                  <option>AWS SNS</option>
                  <option>Local Gateway (Gammu)</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">API Key</label>
                <input type="password" className="form-input" placeholder="••••••••" />
              </div>
              <div className="form-group">
                <label className="form-label">Default SMS Sender ID</label>
                <input type="text" className="form-input" placeholder="CLINIC" />
              </div>
              <div className="form-group">
                <label className="form-label">Reminder Frequency</label>
                <select className="form-input">
                  <option>7, 2, and 1 days before</option>
                  <option>3 and 1 days before</option>
                  <option>1 day before only</option>
                </select>
              </div>
              <button className="btn btn-primary" style={{marginTop: '16px'}}>Save Settings</button>
            </div>
          </>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              New Patient
              <button className="modal-close" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <div className="form-group">
              <label className="form-label">Patient Code</label>
              <input type="text" className="form-input" placeholder="PAT-2024-0004" />
            </div>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input type="text" className="form-input" placeholder="Full name" />
            </div>
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input type="tel" className="form-input" placeholder="+237677123456" />
            </div>
            <div className="form-group">
              <label className="form-label">Conditions</label>
              <select className="form-input" multiple>
                <option>HIV</option>
                <option>TB</option>
                <option>Co-infection (HIV+TB)</option>
              </select>
            </div>
            <div className="action-buttons" style={{justifyContent: 'flex-end'}}>
              <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary">Create Patient</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HealthcareAppointmentDashboard;
