-- ============================================================================
-- HEALTHCARE APPOINTMENT REMINDER SYSTEM - POSTGRESQL DATABASE SCHEMA
-- ============================================================================
-- Run this SQL file to initialize the complete database structure
-- psql -U postgres -d healthcare_db -f init.sql

-- ============================================================================
-- 1. ENABLE EXTENSIONS
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For full-text search

-- ============================================================================
-- 2. ENUM TYPES
-- ============================================================================

CREATE TYPE gender_enum AS ENUM ('M', 'F', 'Other', 'Prefer not to say');

CREATE TYPE appointment_type_enum AS ENUM (
  'hiv_trimester',
  'tb_6month',
  'monthly_pickup',
  'follow_up',
  'other'
);

CREATE TYPE appointment_status_enum AS ENUM (
  'scheduled',
  'completed',
  'missed',
  'rescheduled',
  'cancelled',
  'no_show'
);

CREATE TYPE sms_status_enum AS ENUM (
  'pending',
  'sent',
  'delivered',
  'failed',
  'bounced'
);

CREATE TYPE metric_type_enum AS ENUM (
  'hiv_viral_load',
  'tb_status',
  'cd4_count',
  'hemoglobin',
  'weight',
  'blood_pressure',
  'other'
);

CREATE TYPE metric_status_enum AS ENUM (
  'normal',
  'abnormal',
  'critical',
  'pending'
);

-- ============================================================================
-- 3. PATIENTS TABLE
-- ============================================================================

CREATE TABLE patients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_code VARCHAR(50) UNIQUE NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  phone_number VARCHAR(20) UNIQUE NOT NULL,
  alternate_phone VARCHAR(20),
  email VARCHAR(100),
  date_of_birth DATE,
  gender gender_enum,
  
  -- Clinical Information
  conditions JSONB DEFAULT '{}',  -- {hiv: true, tb: true, malaria: false}
  enrollment_date TIMESTAMP DEFAULT NOW(),
  clinic_id UUID,
  
  -- Contact Preferences
  prefer_sms BOOLEAN DEFAULT true,
  prefer_call BOOLEAN DEFAULT false,
  sms_language VARCHAR(10) DEFAULT 'en',  -- en, fr, es
  
  -- Status
  active BOOLEAN DEFAULT true,
  last_appointment_date TIMESTAMP,
  next_appointment_date TIMESTAMP,
  
  -- Metadata
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by UUID,
  updated_by UUID,
  
  -- Indexing for performance
  CONSTRAINT phone_format CHECK (phone_number ~ '^\+?[0-9]{7,15}$')
);

CREATE INDEX idx_patients_code ON patients(patient_code);
CREATE INDEX idx_patients_phone ON patients(phone_number);
CREATE INDEX idx_patients_email ON patients(email);
CREATE INDEX idx_patients_active ON patients(active) WHERE active = true;
CREATE INDEX idx_patients_next_appointment ON patients(next_appointment_date);
CREATE INDEX idx_patients_created_at ON patients(created_at DESC);

-- ============================================================================
-- 4. APPOINTMENTS TABLE
-- ============================================================================

CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  
  -- Appointment Details
  appointment_type appointment_type_enum NOT NULL,
  scheduled_date TIMESTAMP NOT NULL,
  expected_duration_minutes INT DEFAULT 30,
  location VARCHAR(255),
  provider_name VARCHAR(100),
  notes TEXT,
  
  -- Status Tracking
  status appointment_status_enum DEFAULT 'scheduled',
  last_appointment_date TIMESTAMP,
  
  -- Reminder Status
  reminder_sent BOOLEAN DEFAULT false,
  reminder_sent_at TIMESTAMP,
  reminder_count INT DEFAULT 0,
  
  -- Cancellation Info
  cancellation_reason TEXT,
  cancelled_at TIMESTAMP,
  cancelled_by UUID,
  
  -- Rescheduling Info
  rescheduled_from UUID REFERENCES appointments(id),
  rescheduled_at TIMESTAMP,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by UUID,
  updated_by UUID,
  
  CONSTRAINT appointment_date_valid CHECK (scheduled_date > NOW())
);

CREATE INDEX idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX idx_appointments_scheduled_date ON appointments(scheduled_date);
CREATE INDEX idx_appointments_status ON appointments(status);
CREATE INDEX idx_appointments_upcoming ON appointments(scheduled_date) 
  WHERE status = 'scheduled' AND scheduled_date > NOW();
CREATE INDEX idx_appointments_reminder_needed ON appointments(scheduled_date) 
  WHERE reminder_sent = false AND status = 'scheduled';
CREATE INDEX idx_appointments_patient_date ON appointments(patient_id, scheduled_date DESC);

-- ============================================================================
-- 5. HEALTH METRICS TABLE
-- ============================================================================

CREATE TABLE health_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  
  -- Metric Information
  metric_type metric_type_enum NOT NULL,
  metric_value VARCHAR(255) NOT NULL,
  metric_value_numeric NUMERIC(10, 2),  -- For calculations
  unit VARCHAR(50),
  
  -- Reference Ranges
  measurement_date DATE NOT NULL DEFAULT CURRENT_DATE,
  normal_range VARCHAR(100),
  status metric_status_enum DEFAULT 'pending',
  
  -- Additional Info
  test_name VARCHAR(255),
  lab_name VARCHAR(255),
  notes TEXT,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  created_by UUID
);

CREATE INDEX idx_metrics_patient_id ON health_metrics(patient_id);
CREATE INDEX idx_metrics_type ON health_metrics(metric_type);
CREATE INDEX idx_metrics_date ON health_metrics(measurement_date DESC);
CREATE INDEX idx_metrics_status ON health_metrics(status);
CREATE INDEX idx_metrics_patient_type_date ON health_metrics(patient_id, metric_type, measurement_date DESC);

-- ============================================================================
-- 6. SMS TEMPLATES TABLE
-- ============================================================================

CREATE TABLE sms_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  appointment_type appointment_type_enum,
  
  -- Message Template
  message TEXT NOT NULL,
  
  -- Template Variables (e.g., [PATIENT_NAME], [APPOINTMENT_DATE], [LOCATION])
  variables JSONB DEFAULT '{}',
  
  -- Reminder Timing
  days_before INT NOT NULL,  -- Send 7, 2, or 1 days before
  
  -- Status
  active BOOLEAN DEFAULT true,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by UUID
);

CREATE INDEX idx_templates_active ON sms_templates(active);
CREATE INDEX idx_templates_appointment_type ON sms_templates(appointment_type);
CREATE INDEX idx_templates_days_before ON sms_templates(days_before);

-- Sample templates
INSERT INTO sms_templates (name, appointment_type, message, days_before) VALUES
(
  'HIV Trimester - 7 Days',
  'hiv_trimester',
  'Hello [PATIENT_NAME], your HIV viral load test appointment is in 7 days on [APPOINTMENT_DATE] at [LOCATION]. Please arrive 15 minutes early. Reply CONFIRM to confirm.',
  7
),
(
  'HIV Trimester - 2 Days',
  'hiv_trimester',
  'Reminder: Your appointment is in 2 days on [APPOINTMENT_DATE]. Please confirm by replying CONFIRM or call [CLINIC_PHONE] to reschedule.',
  2
),
(
  'HIV Trimester - 1 Day',
  'hiv_trimester',
  'Your appointment is TOMORROW [APPOINTMENT_DATE] at [LOCATION]. Please arrive 15 minutes early.',
  1
),
(
  'TB Control - 7 Days',
  'tb_6month',
  'Hello [PATIENT_NAME], your TB control appointment is in 7 days on [APPOINTMENT_DATE] at [LOCATION]. Patient Code: [PATIENT_CODE]',
  7
),
(
  'Monthly Pickup - 1 Day',
  'monthly_pickup',
  '[PATIENT_NAME], reminder: Come tomorrow to pick up your medications at [LOCATION].',
  1
);

-- ============================================================================
-- 7. SMS NOTIFICATIONS TABLE
-- ============================================================================

CREATE TABLE sms_notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  sms_template_id UUID REFERENCES sms_templates(id),
  
  -- Message Content
  message TEXT NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  
  -- Delivery Status
  status sms_status_enum DEFAULT 'pending',
  scheduled_for TIMESTAMP,
  sent_at TIMESTAMP,
  delivered_at TIMESTAMP,
  
  -- Provider Information
  provider_name VARCHAR(50),  -- twilio, aws_sns, gammu, etc.
  provider_message_id VARCHAR(255),
  delivery_status JSONB,  -- Full response from provider
  
  -- Retry Logic
  attempt_count INT DEFAULT 0,
  last_attempt_at TIMESTAMP,
  next_retry_at TIMESTAMP,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_sms_patient_id ON sms_notifications(patient_id);
CREATE INDEX idx_sms_status ON sms_notifications(status);
CREATE INDEX idx_sms_scheduled_for ON sms_notifications(scheduled_for);
CREATE INDEX idx_sms_sent_at ON sms_notifications(sent_at DESC);
CREATE INDEX idx_sms_appointment_id ON sms_notifications(appointment_id);
CREATE INDEX idx_sms_pending ON sms_notifications(status, scheduled_for) 
  WHERE status IN ('pending', 'failed');

-- ============================================================================
-- 8. PATIENT RESPONSES TABLE (For SMS replies)
-- ============================================================================

CREATE TABLE patient_responses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  sms_notification_id UUID REFERENCES sms_notifications(id),
  appointment_id UUID REFERENCES appointments(id),
  
  -- Response
  response_text VARCHAR(500),
  response_type VARCHAR(50),  -- confirm, reschedule, cancel, other
  
  -- Phone that responded
  from_phone_number VARCHAR(20),
  
  -- Processing Status
  processed BOOLEAN DEFAULT false,
  processed_at TIMESTAMP,
  processed_by UUID,
  
  -- Created
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_responses_patient_id ON patient_responses(patient_id);
CREATE INDEX idx_responses_processed ON patient_responses(processed) WHERE processed = false;
CREATE INDEX idx_responses_appointment_id ON patient_responses(appointment_id);

-- ============================================================================
-- 9. USERS/STAFF TABLE
-- ============================================================================

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- User Info
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone_number VARCHAR(20),
  
  -- Authentication
  password_hash VARCHAR(255) NOT NULL,
  
  -- Role & Permissions
  role VARCHAR(50) NOT NULL DEFAULT 'staff',  -- admin, staff, nurse, doctor
  permissions JSONB DEFAULT '{}',
  
  -- Status
  active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(active);
CREATE INDEX idx_users_role ON users(role);

-- ============================================================================
-- 10. AUDIT LOG TABLE
-- ============================================================================

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Action Info
  action VARCHAR(100) NOT NULL,  -- create, update, delete, view
  table_name VARCHAR(100) NOT NULL,
  record_id UUID,
  
  -- User Info
  user_id UUID REFERENCES users(id),
  
  -- Changes
  old_values JSONB,
  new_values JSONB,
  
  -- Metadata
  timestamp TIMESTAMP DEFAULT NOW(),
  ip_address VARCHAR(45)
);

CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_table_name ON audit_logs(table_name);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

-- ============================================================================
-- 11. SYSTEM SETTINGS TABLE
-- ============================================================================

CREATE TABLE system_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- SMS Configuration
  sms_provider VARCHAR(50),  -- twilio, aws_sns, gammu
  sms_api_key VARCHAR(500),
  sms_api_secret VARCHAR(500),
  sms_sender_id VARCHAR(50),
  
  -- Reminder Settings
  reminder_days_before TEXT,  -- e.g., "7,2,1"
  reminder_send_time TIME DEFAULT '02:00:00',
  timezone VARCHAR(50) DEFAULT 'UTC',
  
  -- System
  clinic_name VARCHAR(255),
  clinic_phone VARCHAR(20),
  clinic_email VARCHAR(100),
  clinic_address TEXT,
  
  -- Feature Flags
  enable_sms_reminders BOOLEAN DEFAULT true,
  enable_call_reminders BOOLEAN DEFAULT false,
  enable_email_reminders BOOLEAN DEFAULT false,
  
  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  updated_by UUID
);

-- ============================================================================
-- 12. TRIGGERS & FUNCTIONS
-- ============================================================================

-- Update patient's updated_at timestamp
CREATE OR REPLACE FUNCTION update_patient_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_patients_timestamp
BEFORE UPDATE ON patients
FOR EACH ROW
EXECUTE FUNCTION update_patient_timestamp();

-- Auto-update patient's next appointment date
CREATE OR REPLACE FUNCTION update_patient_next_appointment()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE patients 
  SET next_appointment_date = (
    SELECT scheduled_date FROM appointments 
    WHERE patient_id = NEW.patient_id 
    AND status = 'scheduled'
    AND scheduled_date > NOW()
    ORDER BY scheduled_date ASC
    LIMIT 1
  )
  WHERE id = NEW.patient_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_next_appointment
AFTER INSERT OR UPDATE ON appointments
FOR EACH ROW
EXECUTE FUNCTION update_patient_next_appointment();

-- Log all changes to patients table
CREATE OR REPLACE FUNCTION log_patient_changes()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO audit_logs (action, table_name, record_id, old_values, new_values, user_id)
  VALUES (
    TG_OP,
    'patients',
    NEW.id,
    to_jsonb(OLD),
    to_jsonb(NEW),
    NEW.updated_by
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER log_patient_changes_trigger
AFTER UPDATE ON patients
FOR EACH ROW
EXECUTE FUNCTION log_patient_changes();

-- ============================================================================
-- 13. VIEWS FOR REPORTING
-- ============================================================================

-- View: Upcoming Appointments (Next 30 Days)
CREATE OR REPLACE VIEW vw_upcoming_appointments AS
SELECT 
  a.id,
  a.scheduled_date,
  p.patient_code,
  p.first_name,
  p.last_name,
  p.phone_number,
  a.appointment_type,
  a.status,
  a.location,
  p.conditions,
  EXTRACT(DAY FROM a.scheduled_date - NOW()) as days_until
FROM appointments a
JOIN patients p ON a.patient_id = p.id
WHERE a.status = 'scheduled'
  AND a.scheduled_date BETWEEN NOW() AND NOW() + INTERVAL '30 days'
  AND p.active = true
ORDER BY a.scheduled_date ASC;

-- View: Overdue Appointments
CREATE OR REPLACE VIEW vw_overdue_appointments AS
SELECT 
  p.id,
  p.patient_code,
  p.first_name,
  p.last_name,
  p.phone_number,
  MAX(a.scheduled_date) as last_scheduled_date,
  EXTRACT(DAY FROM NOW() - MAX(a.scheduled_date)) as days_overdue
FROM patients p
LEFT JOIN appointments a ON p.patient_id = a.id
WHERE p.active = true
  AND (
    p.next_appointment_date IS NULL 
    OR p.next_appointment_date < NOW()
  )
GROUP BY p.id, p.patient_code, p.first_name, p.last_name, p.phone_number
HAVING MAX(a.scheduled_date) < NOW() OR MAX(a.scheduled_date) IS NULL;

-- View: Appointment Compliance
CREATE OR REPLACE VIEW vw_appointment_compliance AS
SELECT 
  p.id,
  p.patient_code,
  p.first_name,
  p.last_name,
  COUNT(CASE WHEN a.status = 'completed' THEN 1 END) as attended,
  COUNT(CASE WHEN a.status IN ('missed', 'no_show') THEN 1 END) as missed,
  COUNT(*) as total_appointments,
  ROUND(100.0 * COUNT(CASE WHEN a.status = 'completed' THEN 1 END) / NULLIF(COUNT(*), 0), 2) as compliance_percentage
FROM patients p
LEFT JOIN appointments a ON p.patient_id = a.id
WHERE p.active = true
GROUP BY p.id, p.patient_code, p.first_name, p.last_name;

-- View: SMS Delivery Report
CREATE OR REPLACE VIEW vw_sms_delivery_report AS
SELECT 
  DATE(sn.sent_at) as send_date,
  st.appointment_type,
  COUNT(*) as total_sent,
  COUNT(CASE WHEN sn.status = 'delivered' THEN 1 END) as delivered,
  COUNT(CASE WHEN sn.status = 'failed' THEN 1 END) as failed,
  ROUND(100.0 * COUNT(CASE WHEN sn.status = 'delivered' THEN 1 END) / NULLIF(COUNT(*), 0), 2) as delivery_rate
FROM sms_notifications sn
LEFT JOIN sms_templates st ON sn.sms_template_id = st.id
WHERE sn.sent_at IS NOT NULL
GROUP BY DATE(sn.sent_at), st.appointment_type
ORDER BY send_date DESC;

-- ============================================================================
-- 14. SAMPLE DATA (Optional - for testing)
-- ============================================================================

-- Insert sample clinic admin user
INSERT INTO users (first_name, last_name, email, phone_number, password_hash, role) 
VALUES ('Admin', 'User', 'admin@clinic.cm', '+237670000001', 
  '$2b$10$YIjlrPDtWeS4BmWH4c1H.OPST9/PgBKIgCk5PQf0bsHvKQwyrSWHS', 'admin');  -- password: admin123

-- Insert system settings
INSERT INTO system_settings (sms_provider, sms_sender_id, clinic_name, clinic_phone, clinic_email) 
VALUES ('twilio', 'CLINIC', 'Yaoundé Medical Center', '+237222123456', 'info@clinic.cm');

-- ============================================================================
-- 15. ADDITIONAL INDEXES FOR PERFORMANCE
-- ============================================================================

-- Full-text search on patient names
CREATE INDEX idx_patients_search ON patients USING GIN (
  to_tsvector('english', first_name || ' ' || last_name)
);

-- Partial index for active pending SMS
CREATE INDEX idx_sms_pending_delivery ON sms_notifications(scheduled_for) 
WHERE status IN ('pending', 'failed') 
AND scheduled_for <= NOW();

-- ============================================================================
-- 16. COMMENTS FOR DOCUMENTATION
-- ============================================================================

COMMENT ON TABLE patients IS 'Main patient registry with health conditions and contact information';
COMMENT ON TABLE appointments IS 'Appointment scheduling and status tracking';
COMMENT ON TABLE health_metrics IS 'Patient health measurements (viral load, TB status, etc.)';
COMMENT ON TABLE sms_notifications IS 'SMS reminder delivery tracking';
COMMENT ON TABLE sms_templates IS 'Customizable SMS reminder templates';
COMMENT ON TABLE users IS 'Staff and administrator accounts';
COMMENT ON TABLE audit_logs IS 'Complete audit trail of all data modifications';

COMMENT ON COLUMN patients.patient_code IS 'Unique patient identifier from hospital system';
COMMENT ON COLUMN patients.conditions IS 'JSON object storing patient conditions (HIV, TB, etc.)';
COMMENT ON COLUMN appointments.scheduled_date IS 'Appointment date and time in UTC';
COMMENT ON COLUMN health_metrics.metric_type IS 'Type of health measurement (viral load, CD4, etc.)';
COMMENT ON COLUMN sms_notifications.status IS 'Current SMS delivery status (pending, sent, failed, etc.)';

-- ============================================================================
-- GRANT PERMISSIONS (for different user roles)
-- ============================================================================

-- Create database roles
CREATE ROLE api_user WITH LOGIN PASSWORD 'api_secure_password_here';
CREATE ROLE readonly_user WITH LOGIN PASSWORD 'readonly_password_here';

-- Grant permissions for API user (can read and write)
GRANT USAGE ON SCHEMA public TO api_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO api_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO api_user;

-- Grant permissions for read-only user (reporting)
GRANT USAGE ON SCHEMA public TO readonly_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly_user;
GRANT SELECT ON ALL VIEWS IN SCHEMA public TO readonly_user;

-- ============================================================================
-- BACKUP & RESTORE COMMANDS
-- ============================================================================

/*
BACKUP DATABASE:
pg_dump -h localhost -U postgres healthcare_db > backup_$(date +%Y%m%d_%H%M%S).sql

RESTORE DATABASE:
psql -h localhost -U postgres -d healthcare_db < backup_20240331_120000.sql

BACKUP WITH COMPRESSION:
pg_dump -h localhost -U postgres healthcare_db | gzip > backup_$(date +%Y%m%d).sql.gz

RESTORE FROM COMPRESSED BACKUP:
gunzip -c backup_20240331.sql.gz | psql -h localhost -U postgres -d healthcare_db

VERIFY DATABASE:
psql -h localhost -U postgres -d healthcare_db -c "\dt"  -- List tables
psql -h localhost -U postgres -d healthcare_db -c "\di"  -- List indexes
*/

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================

GRANT ALL PRIVILEGES ON DATABASE healthcare_db TO api_user;

\echo '✅ Healthcare Appointment System Database Schema Created Successfully'
\echo ''
\echo 'Created Tables:'
\echo '  - patients (patient registry)'
\echo '  - appointments (appointment scheduling)'
\echo '  - health_metrics (test results and measurements)'
\echo '  - sms_notifications (reminder delivery tracking)'
\echo '  - sms_templates (message templates)'
\echo '  - patient_responses (SMS reply handling)'
\echo '  - users (staff accounts)'
\echo '  - audit_logs (change tracking)'
\echo '  - system_settings (configuration)'
\echo ''
\echo 'Views:'
\echo '  - vw_upcoming_appointments'
\echo '  - vw_overdue_appointments'
\echo '  - vw_appointment_compliance'
\echo '  - vw_sms_delivery_report'
\echo ''
\echo '✅ Database is ready for use'
